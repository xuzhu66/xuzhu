let obj = {
    "code": 200,
    "success": true,
    "data": {
        "orderAmt": 1600,
        "virOrderAmt": 251.177,
        "currency": "CNY",
        "virCurrency": "USDT-TRC20",
        "protocol": "TRC20",
        "unitPrice": 6.37,
        "recAcctNo": "TEVoYyemhtDRhNAmDo1eEQ1KRuvMZCEWJy",
        "orderDepositId": "1407656816763179009",
        "payTypeGroupName": "聚合支付2",
        "status": "",
        "createTime": ""
    },
    "msg": "操作成功"
}
