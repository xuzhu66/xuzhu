<template lang="pug">
    .chess-page
        Banner(:bannerType="bannerType")
        Notice
        BannerItem(:seatType="bannerType")
</template>
<script>
import BannerItem from "@/views/template3/home/component/bannerItem";
import Banner from '@pon/template3/banner'; // Banner轮播图片
import Notice from '@pon/template3/notice'; // 公告栏
export default {
    name: 'chess', // 玩家
    components: {
        BannerItem,
        Banner,
        Notice
    },
    computed: {},
    props: {},
    data() {
        return {
            bannerType: 2, // 0 首页 1 真人娱乐 2 棋牌游戏 3 电子游戏 4 捕鱼游戏 5 彩票投注 6 电子竞技 7 体育投注 8 优惠活动
            list: [],
        }
    },
    created() {

    },
    watch: {},
    mounted() {

    },
    methods: {}
}
</script>
<style lang="stylus" scoped>
@import '~@/assets/styles/template3/themes/mixin.styl'
@import "~@styl/template3/common/fun.styl"
.chess-page
    position relative

</style>
