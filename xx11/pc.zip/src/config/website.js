/**
 * 全局配置文件
 */
 export default {
    clientId: 'pc', // 客户端id
    clientSecret: 'pc_secret' // 客户端密钥
}
