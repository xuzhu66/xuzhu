// param: {
//   pageSize: this.pageSize,
//     // 如果传了page值，则减 1 进行调用接口
//     page: postPage === undefined ? this.page - 1 : postPage - 1,
//     memberName: this.memberName,
//     realName: this.realName,
//     payWay: this.payWay,
//     orderStatus: this.orderStatus,
//     orderReview: this.orderReview,
//     depositAmountStart: this.depositAmountEnd,
//     depositAmountEnd: this.depositAmountEnd,
//     payTime: this.payTime,
//     orderCreateTime: this.orderCreateTime
// },
// const getSearchParam = (state) => {
//   return {
//     pageSize: this.pageSize,
//     // 如果传了page值，则减 1 进行调用接口
//     page: postPage === undefined ? this.page - 1 : postPage - 1,
//     memberName: this.memberName,
//     realName: this.realName,
//     payWay: this.payWay,
//     orderStatus: this.orderStatus,
//     orderReview: this.orderReview,
//     depositAmountStart: this.depositAmountEnd,
//     depositAmountEnd: this.depositAmountEnd,
//     payTime: this.payTime,
//     orderCreateTime: this.orderCreateTime
//   };
// };
//
// export default {
//   getSearchParam
// };
