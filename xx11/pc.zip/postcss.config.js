module.exports = {
  // plugins: {
  //   autoprefixer: {},
  //   "postcss-px2rem": {
  //    remUnit: 55, // 37.5px = 1rem
  //    remPrecision: 2 // rem的小数点后位数
  //   }
  // }
};