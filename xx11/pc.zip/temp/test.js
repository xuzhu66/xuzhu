let cnzz = "['https://sdk.51.la/js-sdk-pro.min.js?type=google','https://sdk.51.la/js-sdk-pro.min.js?type=51&id=Jd6P9B0TazaH52mO&ck=Jd6P9B0TazaH52mO','https://sdk.51.la/js-sdk-pro.min.js?type=51&id=Jd6P9B0TazaH52mO&ck=Jd6P9B0TazaH52mO']"

cnzz = cnzz.replace(/'/g,'"')
console.log(JSON.parse(cnzz));
