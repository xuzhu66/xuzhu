var WGURL = {
    version:"2021.10.18.01"
}
