
### store公用问题:  
    除了home banner store 外 其它的公用;

### 个人中心view公用问题:  
    模板二 模板三 继承公用跟人中心; 模板一因为有很多地方不一样, 暂时不做处理; 

test 

test 2